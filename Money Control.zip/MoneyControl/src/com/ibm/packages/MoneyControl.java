package com.ibm.packages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class MoneyControl {

	public static void main(String[] args) {
		//To launch the chrome browser with mentioned website,maximixe the window
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		WebDriverWait wait= new WebDriverWait(driver,60);
		driver.navigate().to("https://www.moneycontrol.com/");	
		driver.manage().window().maximize();	
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//To click on the stock near 'Login' in the page
		WebElement Stock = driver.findElement(By.xpath("//a[@href='//www.moneycontrol.com/india/stockpricequote/']"));
		Stock.click();
		//To click on the company with name 'A'
		WebElement ClickA=driver.findElement(By.xpath("//a[@href='/india/stockpricequote/A']"));
		ClickA.click();
		//To get the link in that page with company name 'A'
		List<WebElement> linkTag= driver.findElements(By.tagName("link"));
        System.out.println("The no.of link tag is:" +linkTag.size());
        for (WebElement link : linkTag ) {
        	System.out.println("The link is:" +link.getAttribute("href"));
        	System.out.println(link.getText());
        }
        //To go to the company 'Ashok Leyland' sending that value to the inpu box in top
        WebElement Company=driver.findElement(By.xpath("//input[@name='company']"));
        Company.sendKeys("Ashok Leyland");
        //After giving the company name and then click on 'GO' near the input box
        WebElement GoClick= driver.findElement(By.xpath("//input[@src='http://img-d02.moneycontrol.co.in/images/technicals/go_btn.jpg']"));
        GoClick.click();
        //Once 'Go' is clicked it enter a new page and in the new page to click on the 'Ashok Leyland' company
        WebElement AshokLeyland= driver.findElement(By.xpath("//a[@href='http://www.moneycontrol.com/india/stockpricequote/autolcvshcvs/ashokleyland/AL']"));
        AshokLeyland.click();
        //To check whether the Company title is matching with company name
        Assert.assertTrue(driver.findElement(By.xpath("//div[@class='b_42 MB10 PT5 PR']")).isDisplayed());
        //To check whether all the statements are executed and print as it is displayed
        System.out.println("The Title is displayed as Ashok Leyland");


}
}
