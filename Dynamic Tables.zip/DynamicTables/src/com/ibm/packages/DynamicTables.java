package com.ibm.packages;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
public class DynamicTables {

	public static void main(String[] args) {
		//To initialize Chrome driver
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		//Explicit wait 
		WebDriverWait wait= new WebDriverWait(driver,60);
		//To launch the mentioned url
		driver.navigate().to("https://datatables.net");	
		//To maximize the window
		driver.manage().window().maximize();
		//Implicit wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//To have 100 entries
		WebElement show= driver.findElement(By.xpath("//option[@value='100']"));
		show.click();
		//To get the row count
		List <WebElement> rows= driver.findElements(By.xpath("//table[@id='example']/tbody/tr"));
		int row=rows.size();
		
		System.out.println("The row count is:" +row);
		//Loop statement to get the data for name, age, salary when age is gretaer than or equal to 50 and salary greater than or equal to 200000
			for(int i = 1;i<=row;i++)
				
					{
			WebElement name= driver.findElement(By.xpath("//table[@id='example']/tbody/tr[("+i+")]/td[1]"));
		    String Name= name.getText();
		    WebElement age=driver.findElement(By.xpath("//table[@id='example']/tbody/tr[("+i+")]/td[4]"));
			String ages=age.getText();
			name.click();
		    WebElement Salary= driver.findElement(By.xpath("//table[@id='example']/tbody/tr[("+(i+1)+")]/td[1]"));
		    String salary= Salary.getText().trim().replace("Salary","").trim().replace("$", "").replace(",","");
		    name.click();
		    if((Integer.parseInt(ages)>=50) && (Integer.parseInt(salary)>=200000) )
		    {
		    System.out.println(Name);
		    System.out.println(ages);
		    System.out.println(salary);
		    }
		    
					}
}
}
